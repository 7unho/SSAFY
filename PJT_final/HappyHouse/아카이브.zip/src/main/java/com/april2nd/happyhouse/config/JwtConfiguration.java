package com.april2nd.happyhouse.config;

public class JwtConfiguration {

}
