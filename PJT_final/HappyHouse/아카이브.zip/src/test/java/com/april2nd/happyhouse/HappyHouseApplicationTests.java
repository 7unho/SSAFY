package com.april2nd.happyhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HappyHouseApplicationTests {

    @Test
    void contextLoads() {
    }

}
